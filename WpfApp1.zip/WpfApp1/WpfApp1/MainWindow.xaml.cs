﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            pozdrav.Content = "Ahoj";
            if (textik.Text == "")
            {
                MessageBox.Show("Pole je prázdné");
            }
            else
            {
                pozdrav.Content = textik.Text;
            }

            }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void pozdrav_MouseEnter(object sender, MouseEventArgs e)
        {
            Random rnd = new Random();
            byte r = (byte)rnd.Next(0, 255);
            byte g = (byte)rnd.Next(0, 255);
            byte b = (byte)rnd.Next(0, 255);

            pozdrav.Background = new SolidColorBrush(Color.FromRgb(r, g, b));
        }
        
        private void scrollR_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            scrollR.Value = e.NewValue;

            labelR.Content = ((int)Math.Round(scrollR.Value)).ToString();
            textR.Text = r.ToString();
        }

        private void scrollG_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            scrollG.Value = e.NewValue;
            
            labelG.Content = ((int)Math.Round(scrollG.Value)).ToString();
            textG.Text = g.ToString();
        }

        private void scrollB_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            scrollB.Value = e.NewValue;
            
            labelB.Content = ((int)Math.Round(scrollB.Value)).ToString();
            textB.Text = b.ToString();
        }
        int r = ((int)Math.Round(scrollR.Value));
        int g = ((int)Math.Round(scrollG.Value));
        int b = ((int)Math.Round(scrollB.Value));
        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textR.Text))
                return;

            if (!int.TryParse(textR.Text, out int hodnota) || hodnota < 0 || hodnota > 255)
            {
                MessageBox.Show(
                    "Zadej celé číslo v rozsahu 0–255.",
                    "Chyba",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );

                textR.TextChanged -= TextBox_TextChanged_1; 
                textR.Text = "0";
                textR.CaretIndex = textR.Text.Length;
                textR.TextChanged += TextBox_TextChanged_1;
                return;
            }
            else
            {
                labelR.Content = hodnota.ToString();
                scrollR.Value = hodnota;
            } 
        }


        private void textG_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textG.Text))
                return;

            if (!int.TryParse(textG.Text, out int hodnota) || hodnota < 0 || hodnota > 255)
            {
                MessageBox.Show(
                    "Zadej celé číslo v rozsahu 0–255.",
                    "Chyba",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );

                textR.TextChanged -= TextBox_TextChanged_1;
                textR.Text = "0";
                textR.CaretIndex = textG.Text.Length;
                textR.TextChanged += TextBox_TextChanged_1;
                return;
            }
            else
            {
                labelG.Content = hodnota.ToString();
                scrollG.Value = hodnota;
            }
        }

        private void textB_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textB.Text))
                return;

            if (!int.TryParse(textB.Text, out int hodnota) || hodnota < 0 || hodnota > 255)
            {
                MessageBox.Show(
                    "Zadej celé číslo v rozsahu 0–255.",
                    "Chyba",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );

                textR.TextChanged -= TextBox_TextChanged_1;
                textR.Text = "0";
                textR.CaretIndex = textB.Text.Length;
                textR.TextChanged += TextBox_TextChanged_1;
                return;
            }
            else
            {
                labelB.Content = hodnota.ToString();
                scrollB.Value = hodnota;
            }
        }
    }
}