﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using To_do_list.Model;

namespace To_do_list.ViewModel
{
    internal class MainWindowViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        public RelayCommand AddTask => new RelayCommand(execute => AddItem());
        public RelayCommand RemoveTask => new RelayCommand(execute => DeleteItem(), canExecute => SelectedItem != null);

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public ObservableCollection<Quest>   Tasks { get; set; }

        public MainWindowViewModel()
        { 
            Tasks = new ObservableCollection<Quest>();
            Tasks.Add(new Quest() { Content = "zalít kytky" });
        }
        private void AddItem()
        {
            Tasks.Add(new Quest()
            {
                Content = "Nový úkol",
            });
        }
        private Quest selectedItem;
        public Quest SelectedItem
        {
            get { return selectedItem; }
            set
            {
                selectedItem = value;
                OnPropertyChanged();
            }
        }
        private void DeleteItem()
        {
            Tasks.Remove(SelectedItem);
        }
    }
}
