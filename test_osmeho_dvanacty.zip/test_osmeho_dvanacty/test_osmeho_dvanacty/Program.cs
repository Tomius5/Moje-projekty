﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
namespace test_osmeho_dvanacty
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines("vstupni_soubory\\1.txt"); //pakliže chete jiný soubor, prostě to tu změňte
            char[][] chars = new char[lines.Length][];

            for (int i = 0; i < lines.Length; i++)
            {
                chars[i] = new char[lines[i].Length];

                for (int j = 0; j < lines[i].Length; j++)
                {
                    chars[i][j] = lines[i][j]; 
                }
            }
            for (int i = 0; i < chars.Length; i++)
            {
                Console.WriteLine(new string(chars[i])); 
            }
            char number_of_obstructions_char = chars[0][0];
            int number_of_obstructions = number_of_obstructions_char - '0';
            char[,] pole = new char[chars.Length, chars.Length];
            for (int i = 1; i < chars.Length - 2; i++)
            {
                for (int j = 0; j < chars[i].Length; j++)
                {
                 //   if (chars[i][j] == ' ') //evidentně nefunguje
                 //       {
                 //       j += 1;
                 //       }
                 //   else
                 //       {
                    pole[i,j] = chars[i][j];
                 //       }
                }
            }
            for (int i = 0; i < chars.Length; i++)
            {
                for (int j = 0; j < chars[i].Length; j++)
                {
                    Console.WriteLine(pole[i,j]);
                } 
            }


            int[,] pole_rucne = new int [8, 8];
            pole_rucne[0,0] = 1;
            pole_rucne[7, 7] = -1;
        }
        public void Turn()
        {
            // Rekurzivní funkce. která zapíše číslo tahu a udělá možný tah
        }
    }
}


